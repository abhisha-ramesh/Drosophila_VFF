"""
This code generates a phase map of furrow depth as a function of central and peripheral stiffness parameters. 
It reads the averaged furrow depth data from text files, constructs a 2D array of final furrow depth values for each parameter combination, 
and visualizes it as a heatmap. The code also exports the data to an Excel file for further analysis.

"""

import os
import numpy as np
import matplotlib.pyplot as plt
font = {'size'   : 40}

plt.rc('font', **font)

# Function to read data and plot the phase map
def plot_phase_map():
    current_directory = os.getcwd()

    # Define the parameter lists for peripheral and central stiffness
    peri_stiffness = [0,2,4,6,8,10,12,14,16,18,20,22,24,26,28,30]
    cent_stiffness = [30,40,50,60,70,80,90,100,110,120,130,140,150,160,170,180,190,200]
    furrow_depth_data = np.zeros((len(cent_stiffness), len(peri_stiffness)))

    # Iterate over files and populate the furrow depth data matrix
    for cent in range(len(cent_stiffness)):
        for peri in range(len(peri_stiffness)):
            file_name_step = f"fd_lambda_cent_{cent_stiffness[cent]}_lambda_peri_{peri_stiffness[peri]}.txt"  # Adjusted file name
            if os.path.exists(file_name_step):
                with open(file_name_step, 'r') as file:
                    for line in file:
                        values = line.strip().split()
                    # extract the final furrow depth value from the time-furrow depth data file and store it in the matrix
                    furrow_depth_data[cent][peri] = float(values[1]) 

    # Plotting heatmap
    plt.figure(figsize=(18, 16))
    plt.imshow(furrow_depth_data, cmap='inferno', aspect='auto', origin='lower', clim=(0.66069905227337, np.max(furrow_depth_data)))
    print(np.min(furrow_depth_data), np.max(furrow_depth_data))
    plt.colorbar(label='Furrow Depth')
    plt.xlabel('Decreasing Peripheral stiffness', color="black",fontsize=40)
    plt.ylabel('Increasing Central stiffness', color="black",fontsize=40)
    plt.xticks([0,5,10,15], [0,10,20,30])
    plt.yticks([0,4,8,12,16], [30,70,110,150,190])
    plt.tick_params(axis='x', colors='black')
    plt.tick_params(axis='y', colors='black')
    plt.title(f'Phase Map for Dynamic Stiffness')
    plt.grid(alpha=0.8)
    plt.tight_layout()
    plt.savefig(f'phase_map.png', dpi=300, bbox_inches='tight')
    plt.show()


def main():
    plot_phase_map()
    
if __name__ == "__main__":
    main()
